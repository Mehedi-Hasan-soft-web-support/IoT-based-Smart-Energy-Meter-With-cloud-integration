# Opening the app in Android Studio

You saw **"Code insight unavailable (related Gradle Project not linked)"** because the
Kotlin files weren't inside a synced Gradle project. This folder is now a complete
project. Do this:

## Requirements
- **Android Studio Hedgehog (2023.1.1) or newer**
- **JDK 17** (bundled with Android Studio — no separate install needed)

## Steps (recommended)
1. In Android Studio: **File → Open…**
2. Select **this `android` folder** — the one that contains `settings.gradle.kts`
   (not a single `.kt` file, not the parent `smart-energy-meter` folder).
3. Click **Trust Project** if asked.
4. Wait for **Gradle sync** to finish (bottom status bar). First time it downloads
   Gradle 8.5 and the libraries, so it needs internet and a few minutes.
5. If it says the **Gradle wrapper** is missing, let it generate/use one (or just
   re-run **File → Sync Project with Gradle Files**).
6. If it complains about the **SDK location**, open **File → Project Structure → SDK
   Location**, or create a `local.properties` file here (see `local.properties.SAMPLE`).
7. Press **Run ▶** on a device or emulator.

## Project structure
```
android/
├─ settings.gradle.kts        <- makes it a linkable project (includes :app)
├─ build.gradle.kts           <- plugin versions (AGP 8.2.2, Kotlin 1.9.22)
├─ gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties  (Gradle 8.5)
└─ app/
   ├─ build.gradle.kts        <- module deps (Compose, Retrofit, …)
   └─ src/main/
      ├─ AndroidManifest.xml
      ├─ res/values/{themes.xml,colors.xml}
      └─ java/com/example/energymeter/*.kt
```

## If it still won't link (fallback — 100% reliable)
1. **New Project → Empty Activity** (the Compose one). Set:
   - Package name: `com.example.energymeter`
   - Language: Kotlin, Minimum SDK: 24
2. After it builds, copy into the generated project:
   - all `*.kt` from `app/src/main/java/com/example/energymeter/`
   - `app/src/main/res/values/themes.xml` and `colors.xml`
   - replace `app/src/main/AndroidManifest.xml`
   - replace the contents of `app/build.gradle.kts` with the one here
3. **Sync Project with Gradle Files**, then **Run ▶**.

Supabase URL + anon key are already set in `SupabaseService.kt`.
