package com.example.energymeter

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class Pal(
    val primary: Color, val secondary: Color,
    val bg: Color, val surface: Color, val card: Color,
    val text: Color, val muted: Color, val line: Color
)

data class ThemeDef(val name: String, val primary: Long, val secondary: Long)

// 20 selectable themes (distinct accent pairs)
val THEMES = listOf(
    ThemeDef("Sunset", 0xFFF2531A, 0xFFF5B301),
    ThemeDef("Ocean", 0xFF2563EB, 0xFF22D3EE),
    ThemeDef("Forest", 0xFF2F8368, 0xFF84CC16),
    ThemeDef("Grape", 0xFF7C3AED, 0xFFEC4899),
    ThemeDef("Cherry", 0xFFE11D48, 0xFFFB7185),
    ThemeDef("Teal", 0xFF0D9488, 0xFF34D399),
    ThemeDef("Indigo", 0xFF4F46E5, 0xFF8B5CF6),
    ThemeDef("Amber", 0xFFD97706, 0xFFB45309),
    ThemeDef("Slate", 0xFF334155, 0xFF3B82F6),
    ThemeDef("RoseGold", 0xFFB76E79, 0xFFE6BE8A),
    ThemeDef("Midnight", 0xFF1E3A8A, 0xFF6D28D9),
    ThemeDef("Mint", 0xFF10B981, 0xFF14B8A6),
    ThemeDef("Coral", 0xFFFF6B6B, 0xFFFFA94D),
    ThemeDef("Lavender", 0xFF8B7FD6, 0xFFB197FC),
    ThemeDef("Cyber", 0xFFF000B8, 0xFF00E5FF),
    ThemeDef("Emerald", 0xFF059669, 0xFF10B981),
    ThemeDef("Crimson", 0xFFDC2626, 0xFFF97316),
    ThemeDef("Sky", 0xFF0EA5E9, 0xFF6366F1),
    ThemeDef("Bronze", 0xFFA16207, 0xFFCA8A04),
    ThemeDef("Mono", 0xFF111827, 0xFF6B7280),
)

val LocalPal = staticCompositionLocalOf<Pal> { error("Pal not provided") }

@Composable
fun AppTheme(themeIndex: Int, darkMode: Int, content: @Composable () -> Unit) {
    val dark = when (darkMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val t = THEMES[themeIndex.coerceIn(0, THEMES.size - 1)]
    val primary = Color(t.primary); val secondary = Color(t.secondary)
    val pal = if (dark) Pal(
        primary, secondary,
        bg = Color(0xFF0F1218), surface = Color(0xFF171B22), card = Color(0xFF1B2029),
        text = Color(0xFFE9EDF5), muted = Color(0xFF8B93A3), line = Color(0xFF2A2F3A)
    ) else Pal(
        primary, secondary,
        bg = Color(0xFFF3F4F7), surface = Color(0xFFFFFFFF), card = Color(0xFFFFFFFF),
        text = Color(0xFF1C1B1F), muted = Color(0xFF8A8F98), line = Color(0xFFE7E4DD)
    )
    val cs = if (dark) darkColorScheme(primary = primary, background = pal.bg, surface = pal.surface)
             else lightColorScheme(primary = primary, background = pal.bg, surface = pal.surface)
    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = cs, content = content)
    }
}
