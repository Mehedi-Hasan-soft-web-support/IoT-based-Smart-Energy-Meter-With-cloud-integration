//package com.example.energymeter
//
//data class ProjectLink(val label: String, val url: String)
//data class Project(
//    val name: String,
//    val tag: String,
//    val links: List<ProjectLink> = emptyList(),
//    val status: String? = null
//)
//
//object Dev {
//    const val NAME = "Md. Mehedi Hasan"
//    const val ROLE = "Embedded Systems Engineer · IoT Specialist"package com.example.energymeter
//
//    data class ProjectLink(val label: String, val url: String)
//    data class Project(
//        val name: String,
//        val tag: String,
//        val links: List<ProjectLink> = emptyList(),
//        val status: String? = null
//    )
//
//    object Dev {
//        const val NAME = "Md. Mehedi Hasan"
//        const val ROLE = "Embedded Systems Engineer · IoT Specialist"
//        const val INITIALS = "MH"
//        const val BIO =
//            "A multi-disciplinary engineer and researcher with deep expertise in Embedded Systems, " +
//                    "IoT, and Software Development. Hands-on experience building real microcontroller-based " +
//                    "systems, sensor networks, and cloud-connected IoT solutions. Also an active researcher, " +
//                    "event organizer, and educator — with published research, multiple awards, and a rich " +
//                    "portfolio of lectures and projects."
//        const val GITHUB = "https://github.com/Mehedi-Hasan-soft-web-support"
//
//        private const val GH = "https://github.com/Mehedi-Hasan-soft-web-support/"
//
//        val PROJECTS = listOf(
//            Project("Clap Switch (Custom ATmega328P)", "Custom MCU", status = "Demo pending"),
//            Project("IR Remote Controlled LED Lighting System", "Arduino", status = "Demo pending"),
//            Project("Real-Time Smoke Detection System", "IoT",
//                listOf(ProjectLink("Live", "https://mehedi-hasan-soft-web-support.github.io/smoke.github.io/"))),
//            Project("Home Automation using PIR Sensor & Arduino UNO R3", "Automation",
//                listOf(ProjectLink("Video", "https://www.youtube.com/watch?v=ylutRmqeahs&t=4s"))),
//            Project("Poultry Farm Environment Monitoring (ESP32 + ThingSpeak)", "ESP32 · Cloud",
//                listOf(ProjectLink("Code", GH + "Poultry-Farm-Environment-Monitoring-System-using-ESP32-and-ThingSpeak"),
//                    ProjectLink("Live", "https://me497d.github.io/PoultryAirSense/index.html"))),
//            Project("Plant Growth Monitoring (Humidity, Temp & Light)", "Sensors",
//                listOf(ProjectLink("Code", GH + "Plant-Growth-Monitoring-System-Using-humidity-tempareture-and-Light-intensive-value-"))),
//            Project("Embedded Voting Machine (Coupon Auth + ThingSpeak)", "Embedded",
//                listOf(ProjectLink("Code", GH + "Embedded-Voting-Machine-with-Coupon-Authentication-and-ThingSpeak-Cloud-Integration"))),
//            Project("Arduino Logic Gate Simulator with OLED Display", "Arduino",
//                listOf(ProjectLink("Code", GH + "logic-Gate-Simulator-using-Arduino-Nano"))),
//            Project("Arduino Radar", "Arduino",
//                listOf(ProjectLink("Code", GH + "Arduino-Raddar"))),
//            Project("Dual-Ultrasonic-Sensor-Based Relay Control System", "Arduino",
//                listOf(ProjectLink("Code", GH + "Dual-Ultrasonic-Sensor-Based-Relay-Control-System"))),
//            Project("RFID Attendance System (Arduino UNO R3)", "RFID",
//                listOf(ProjectLink("Code", GH + "RFID-Attendence-System-Using-Arduino-UNO-R3-"))),
//            Project("Arduino-Based Smart Home Automation System", "Automation",
//                listOf(ProjectLink("Post", "https://www.facebook.com/share/p/1E9gTmgTb3/"))),
//            Project("Fire Detection System (custom ATmega328P chip)", "Custom MCU",
//                listOf(ProjectLink("Code", GH + "Fire-Detection-System--with-custom-Arduino/tree/main"))),
//            Project("ESP32 BLE Presentation Remote with OLED", "ESP32 · BLE",
//                listOf(ProjectLink("Code", GH + "ESP32-BLE-Presentation-Remote-OLED/tree/main"))),
//            Project("Soil-Air-Monitor (ESP32, DHT11, DS18B20, BH1750, ThingSpeak)", "ESP32 · Cloud",
//                listOf(ProjectLink("Code", GH + "soil-air-monitor"))),
//            Project("ESP32 Plant Growth Monitoring (Light Dependency, Cloud)", "ESP32",
//                listOf(ProjectLink("Code", GH + "ESP32-Based-Plant-Growth-Light-Dependency-Sensor-with-Cloud-Monitoring"))),
//            Project("ESP32-CAM Telegram Multi-User Photo Streamer", "ESP32-CAM",
//                listOf(ProjectLink("Code", GH + "ESP32-CAM-Telegram-Multi-User-Photo-Streamer"))),
//            Project("RFID Attendance + ThingSpeak Cloud & Custom Website", "RFID · Web",
//                listOf(ProjectLink("Code", GH + "RFID-Bassed-attendence-system-with-thinkspeak-cloud-"))),
//            Project("IoT Teacher Portal with RFID & MySQL Integration", "IoT · Web",
//                listOf(ProjectLink("Code", GH + "IoT-Teacher-Portal-with-RFID-and-MySQL-Integration/tree/main"))),
//            Project("IoT Poultry Brooding Temperature Control (ESP32)", "ESP32 · IoT",
//                listOf(ProjectLink("Code", GH + "IoT-Based-Poultry-Brooding-Temperature-Control-System-Using-ESP32/tree/main"))),
//            Project("Arduino Real-Time Time & Temperature", "Arduino",
//                listOf(ProjectLink("Code", GH + "Arduino-based-Real-time-Time-and-Tempareture-/tree/main"))),
//            Project("SmartBrooder", "IoT",
//                listOf(ProjectLink("Code", GH + "SmartBrooder"))),
//            Project("Blynk with DHT11 & LED Control", "Blynk",
//                listOf(ProjectLink("Code", GH + "Handbook/blob/main/Blynk_with_DHT11_and_LED_control.ino"))),
//            Project("OnathSeba: Smart Food Distribution for Street Children", "IoT · AI",
//                listOf(ProjectLink("Code", GH + "SmartBrooder"))),
//            Project("Multinode Gateway Earthquake Detection System", "ESP32 · Gateway",
//                listOf(ProjectLink("Code", GH + "ESP32-based-IoT-gateway-/tree/main"))),
//            Project("XiaoZhi Talking AI Robot (ESP32 + Custom PCB)", "AI · PCB",
//                listOf(ProjectLink("Post", "https://www.facebook.com/groups/658139796738196/permalink/918813270670846/"))),
//            Project("ESP32 Internal Health Monitoring (Custom Library)", "Research", status = "In research"),
//            Project("Blockchain-Based IoT Network Development", "Research", status = "In research"),
//            Project("IFTTT-Based Water TDS Quality Monitor", "IoT",
//                listOf(ProjectLink("Code", GH + "IFTTT-Based-Water-TDS-Quality-Monitor/tree/main"))),
//            Project("TinyML Edge-AI Environmental Monitoring Prototype", "TinyML", status = "Prototype"),
//            Project("ESP32 OLED Robot Face — 35 Modes (Games + Clock + Animations)", "ESP32 · Display",
//                listOf(ProjectLink("Code", GH + "ESP32-OLED-Robot-Face-35-Modes-Smart-Display-Games-Clock-Animations-/tree/main"))),
//            Project("IoT Arrhythmia Detection & Prediction System", "IoT · Health",
//                listOf(ProjectLink("Code", GH + "IoT-based-Arrhythmia-detection-and-prediction-system"))),
//            Project("BLE-Based Smart Attendance System (Secret Algorithm)", "BLE", status = "Private"),
//            Project("HydroWatch: ESP32 Smart Water Monitoring (Cloud)", "ESP32 · Cloud",
//                listOf(ProjectLink("Code", GH + "IoT-Based-Hydroponic-plant-Monitoring-and-Water-Quality-Analysis-"))),
//            Project("RGB Picture Printing on Rounded SPI OLED Display", "Display",
//                listOf(ProjectLink("Code", GH + "RGB-picture-printing-magic-on-Rounded-SPI-OLED-Display"))),
//            Project("ESP32-CAM Web-Based Surveillance System", "ESP32-CAM",
//                listOf(ProjectLink("Code", GH + "ESP32-Cam-Custom-web-server"))),
//            Project("ESP32 LoRa Bridge Communication System", "LoRa · Research", status = "Research"),
//            Project("Prossash: IoT Nebulizer & Patient Tracking System", "IoT · Health",
//                listOf(ProjectLink("Code", GH + "Prossas")))
//        )
//    }
//
//    const val INITIALS = "MH"
//    const val BIO =
//        "A multi-disciplinary engineer and researcher with deep expertise in Embedded Systems, " +
//        "IoT, and Software Development. Hands-on experience building real microcontroller-based " +
//        "systems, sensor networks, and cloud-connected IoT solutions. Also an active researcher, " +
//        "event organizer, and educator — with published research, multiple awards, and a rich " +
//        "portfolio of lectures and projects."
//    const val GITHUB = "https://github.com/Mehedi-Hasan-soft-web-support"
//
//    private const val GH = "https://github.com/Mehedi-Hasan-soft-web-support/"
//
//    val PROJECTS = listOf(
//        Project("Clap Switch (Custom ATmega328P)", "Custom MCU", status = "Demo pending"),
//        Project("IR Remote Controlled LED Lighting System", "Arduino", status = "Demo pending"),
//        Project("Real-Time Smoke Detection System", "IoT",
//            listOf(ProjectLink("Live", "https://mehedi-hasan-soft-web-support.github.io/smoke.github.io/"))),
//        Project("Home Automation using PIR Sensor & Arduino UNO R3", "Automation",
//            listOf(ProjectLink("Video", "https://www.youtube.com/watch?v=ylutRmqeahs&t=4s"))),
//        Project("Poultry Farm Environment Monitoring (ESP32 + ThingSpeak)", "ESP32 · Cloud",
//            listOf(ProjectLink("Code", GH + "Poultry-Farm-Environment-Monitoring-System-using-ESP32-and-ThingSpeak"),
//                   ProjectLink("Live", "https://me497d.github.io/PoultryAirSense/index.html"))),
//        Project("Plant Growth Monitoring (Humidity, Temp & Light)", "Sensors",
//            listOf(ProjectLink("Code", GH + "Plant-Growth-Monitoring-System-Using-humidity-tempareture-and-Light-intensive-value-"))),
//        Project("Embedded Voting Machine (Coupon Auth + ThingSpeak)", "Embedded",
//            listOf(ProjectLink("Code", GH + "Embedded-Voting-Machine-with-Coupon-Authentication-and-ThingSpeak-Cloud-Integration"))),
//        Project("Arduino Logic Gate Simulator with OLED Display", "Arduino",
//            listOf(ProjectLink("Code", GH + "logic-Gate-Simulator-using-Arduino-Nano"))),
//        Project("Arduino Radar", "Arduino",
//            listOf(ProjectLink("Code", GH + "Arduino-Raddar"))),
//        Project("Dual-Ultrasonic-Sensor-Based Relay Control System", "Arduino",
//            listOf(ProjectLink("Code", GH + "Dual-Ultrasonic-Sensor-Based-Relay-Control-System"))),
//        Project("RFID Attendance System (Arduino UNO R3)", "RFID",
//            listOf(ProjectLink("Code", GH + "RFID-Attendence-System-Using-Arduino-UNO-R3-"))),
//        Project("Arduino-Based Smart Home Automation System", "Automation",
//            listOf(ProjectLink("Post", "https://www.facebook.com/share/p/1E9gTmgTb3/"))),
//        Project("Fire Detection System (custom ATmega328P chip)", "Custom MCU",
//            listOf(ProjectLink("Code", GH + "Fire-Detection-System--with-custom-Arduino/tree/main"))),
//        Project("ESP32 BLE Presentation Remote with OLED", "ESP32 · BLE",
//            listOf(ProjectLink("Code", GH + "ESP32-BLE-Presentation-Remote-OLED/tree/main"))),
//        Project("Soil-Air-Monitor (ESP32, DHT11, DS18B20, BH1750, ThingSpeak)", "ESP32 · Cloud",
//            listOf(ProjectLink("Code", GH + "soil-air-monitor"))),
//        Project("ESP32 Plant Growth Monitoring (Light Dependency, Cloud)", "ESP32",
//            listOf(ProjectLink("Code", GH + "ESP32-Based-Plant-Growth-Light-Dependency-Sensor-with-Cloud-Monitoring"))),
//        Project("ESP32-CAM Telegram Multi-User Photo Streamer", "ESP32-CAM",
//            listOf(ProjectLink("Code", GH + "ESP32-CAM-Telegram-Multi-User-Photo-Streamer"))),
//        Project("RFID Attendance + ThingSpeak Cloud & Custom Website", "RFID · Web",
//            listOf(ProjectLink("Code", GH + "RFID-Bassed-attendence-system-with-thinkspeak-cloud-"))),
//        Project("IoT Teacher Portal with RFID & MySQL Integration", "IoT · Web",
//            listOf(ProjectLink("Code", GH + "IoT-Teacher-Portal-with-RFID-and-MySQL-Integration/tree/main"))),
//        Project("IoT Poultry Brooding Temperature Control (ESP32)", "ESP32 · IoT",
//            listOf(ProjectLink("Code", GH + "IoT-Based-Poultry-Brooding-Temperature-Control-System-Using-ESP32/tree/main"))),
//        Project("Arduino Real-Time Time & Temperature", "Arduino",
//            listOf(ProjectLink("Code", GH + "Arduino-based-Real-time-Time-and-Tempareture-/tree/main"))),
//        Project("SmartBrooder", "IoT",
//            listOf(ProjectLink("Code", GH + "SmartBrooder"))),
//        Project("Blynk with DHT11 & LED Control", "Blynk",
//            listOf(ProjectLink("Code", GH + "Handbook/blob/main/Blynk_with_DHT11_and_LED_control.ino"))),
//        Project("OnathSeba: Smart Food Distribution for Street Children", "IoT · AI",
//            listOf(ProjectLink("Code", GH + "SmartBrooder"))),
//        Project("Multinode Gateway Earthquake Detection System", "ESP32 · Gateway",
//            listOf(ProjectLink("Code", GH + "ESP32-based-IoT-gateway-/tree/main"))),
//        Project("XiaoZhi Talking AI Robot (ESP32 + Custom PCB)", "AI · PCB",
//            listOf(ProjectLink("Post", "https://www.facebook.com/groups/658139796738196/permalink/918813270670846/"))),
//        Project("ESP32 Internal Health Monitoring (Custom Library)", "Research", status = "In research"),
//        Project("Blockchain-Based IoT Network Development", "Research", status = "In research"),
//        Project("IFTTT-Based Water TDS Quality Monitor", "IoT",
//            listOf(ProjectLink("Code", GH + "IFTTT-Based-Water-TDS-Quality-Monitor/tree/main"))),
//        Project("TinyML Edge-AI Environmental Monitoring Prototype", "TinyML", status = "Prototype"),
//        Project("ESP32 OLED Robot Face — 35 Modes (Games + Clock + Animations)", "ESP32 · Display",
//            listOf(ProjectLink("Code", GH + "ESP32-OLED-Robot-Face-35-Modes-Smart-Display-Games-Clock-Animations-/tree/main"))),
//        Project("IoT Arrhythmia Detection & Prediction System", "IoT · Health",
//            listOf(ProjectLink("Code", GH + "IoT-based-Arrhythmia-detection-and-prediction-system"))),
//        Project("BLE-Based Smart Attendance System (Secret Algorithm)", "BLE", status = "Private"),
//        Project("HydroWatch: ESP32 Smart Water Monitoring (Cloud)", "ESP32 · Cloud",
//            listOf(ProjectLink("Code", GH + "IoT-Based-Hydroponic-plant-Monitoring-and-Water-Quality-Analysis-"))),
//        Project("RGB Picture Printing on Rounded SPI OLED Display", "Display",
//            listOf(ProjectLink("Code", GH + "RGB-picture-printing-magic-on-Rounded-SPI-OLED-Display"))),
//        Project("ESP32-CAM Web-Based Surveillance System", "ESP32-CAM",
//            listOf(ProjectLink("Code", GH + "ESP32-Cam-Custom-web-server"))),
//        Project("ESP32 LoRa Bridge Communication System", "LoRa · Research", status = "Research"),
//        Project("Prossash: IoT Nebulizer & Patient Tracking System", "IoT · Health",
//            listOf(ProjectLink("Code", GH + "Prossas")))
//    )
//}

package com.example.energymeter

data class ProjectLink(val label: String, val url: String)
data class Project(
    val name: String,
    val tag: String,
    val links: List<ProjectLink> = emptyList(),
    val status: String? = null
)

object Dev {
    const val NAME = "Md. Mehedi Hasan"
    const val ROLE = "Embedded Systems Engineer · IoT Specialist"
    const val INITIALS = "MH" // fallback shown if the image fails to load
    const val PROFILE_IMAGE_URL = "https://i.ibb.co/tpRPmLz5/unnamed-1.jpg"
    const val BIO =
        "A multi-disciplinary engineer and researcher with deep expertise in Embedded Systems, " +
                "IoT, and Software Development. Hands-on experience building real microcontroller-based " +
                "systems, sensor networks, and cloud-connected IoT solutions. Also an active researcher, " +
                "event organizer, and educator — with published research, multiple awards, and a rich " +
                "portfolio of lectures and projects."
    const val GITHUB = "https://github.com/Mehedi-Hasan-soft-web-support"

    private const val GH = "https://github.com/Mehedi-Hasan-soft-web-support/"

    val PROJECTS = listOf(
        Project("Clap Switch (Custom ATmega328P)", "Custom MCU", status = "Demo pending"),
        Project("IR Remote Controlled LED Lighting System", "Arduino", status = "Demo pending"),
        Project("Real-Time Smoke Detection System", "IoT",
            listOf(ProjectLink("Live", "https://mehedi-hasan-soft-web-support.github.io/smoke.github.io/"))),
        Project("Home Automation using PIR Sensor & Arduino UNO R3", "Automation",
            listOf(ProjectLink("Video", "https://www.youtube.com/watch?v=ylutRmqeahs&t=4s"))),
        Project("Poultry Farm Environment Monitoring (ESP32 + ThingSpeak)", "ESP32 · Cloud",
            listOf(ProjectLink("Code", GH + "Poultry-Farm-Environment-Monitoring-System-using-ESP32-and-ThingSpeak"),
                ProjectLink("Live", "https://me497d.github.io/PoultryAirSense/index.html"))),
        Project("Plant Growth Monitoring (Humidity, Temp & Light)", "Sensors",
            listOf(ProjectLink("Code", GH + "Plant-Growth-Monitoring-System-Using-humidity-tempareture-and-Light-intensive-value-"))),
        Project("Embedded Voting Machine (Coupon Auth + ThingSpeak)", "Embedded",
            listOf(ProjectLink("Code", GH + "Embedded-Voting-Machine-with-Coupon-Authentication-and-ThingSpeak-Cloud-Integration"))),
        Project("Arduino Logic Gate Simulator with OLED Display", "Arduino",
            listOf(ProjectLink("Code", GH + "logic-Gate-Simulator-using-Arduino-Nano"))),
        Project("Arduino Radar", "Arduino",
            listOf(ProjectLink("Code", GH + "Arduino-Raddar"))),
        Project("Dual-Ultrasonic-Sensor-Based Relay Control System", "Arduino",
            listOf(ProjectLink("Code", GH + "Dual-Ultrasonic-Sensor-Based-Relay-Control-System"))),
        Project("RFID Attendance System (Arduino UNO R3)", "RFID",
            listOf(ProjectLink("Code", GH + "RFID-Attendence-System-Using-Arduino-UNO-R3-"))),
        Project("Arduino-Based Smart Home Automation System", "Automation",
            listOf(ProjectLink("Post", "https://www.facebook.com/share/p/1E9gTmgTb3/"))),
        Project("Fire Detection System (custom ATmega328P chip)", "Custom MCU",
            listOf(ProjectLink("Code", GH + "Fire-Detection-System--with-custom-Arduino/tree/main"))),
        Project("ESP32 BLE Presentation Remote with OLED", "ESP32 · BLE",
            listOf(ProjectLink("Code", GH + "ESP32-BLE-Presentation-Remote-OLED/tree/main"))),
        Project("Soil-Air-Monitor (ESP32, DHT11, DS18B20, BH1750, ThingSpeak)", "ESP32 · Cloud",
            listOf(ProjectLink("Code", GH + "soil-air-monitor"))),
        Project("ESP32 Plant Growth Monitoring (Light Dependency, Cloud)", "ESP32",
            listOf(ProjectLink("Code", GH + "ESP32-Based-Plant-Growth-Light-Dependency-Sensor-with-Cloud-Monitoring"))),
        Project("ESP32-CAM Telegram Multi-User Photo Streamer", "ESP32-CAM",
            listOf(ProjectLink("Code", GH + "ESP32-CAM-Telegram-Multi-User-Photo-Streamer"))),
        Project("RFID Attendance + ThingSpeak Cloud & Custom Website", "RFID · Web",
            listOf(ProjectLink("Code", GH + "RFID-Bassed-attendence-system-with-thinkspeak-cloud-"))),
        Project("IoT Teacher Portal with RFID & MySQL Integration", "IoT · Web",
            listOf(ProjectLink("Code", GH + "IoT-Teacher-Portal-with-RFID-and-MySQL-Integration/tree/main"))),
        Project("IoT Poultry Brooding Temperature Control (ESP32)", "ESP32 · IoT",
            listOf(ProjectLink("Code", GH + "IoT-Based-Poultry-Brooding-Temperature-Control-System-Using-ESP32/tree/main"))),
        Project("Arduino Real-Time Time & Temperature", "Arduino",
            listOf(ProjectLink("Code", GH + "Arduino-based-Real-time-Time-and-Tempareture-/tree/main"))),
        Project("SmartBrooder", "IoT",
            listOf(ProjectLink("Code", GH + "SmartBrooder"))),
        Project("Blynk with DHT11 & LED Control", "Blynk",
            listOf(ProjectLink("Code", GH + "Handbook/blob/main/Blynk_with_DHT11_and_LED_control.ino"))),
        Project("OnathSeba: Smart Food Distribution for Street Children", "IoT · AI",
            listOf(ProjectLink("Code", GH + "SmartBrooder"))),
        Project("Multinode Gateway Earthquake Detection System", "ESP32 · Gateway",
            listOf(ProjectLink("Code", GH + "ESP32-based-IoT-gateway-/tree/main"))),
        Project("XiaoZhi Talking AI Robot (ESP32 + Custom PCB)", "AI · PCB",
            listOf(ProjectLink("Post", "https://www.facebook.com/groups/658139796738196/permalink/918813270670846/"))),
        Project("ESP32 Internal Health Monitoring (Custom Library)", "Research", status = "In research"),
        Project("Blockchain-Based IoT Network Development", "Research", status = "In research"),
        Project("IFTTT-Based Water TDS Quality Monitor", "IoT",
            listOf(ProjectLink("Code", GH + "IFTTT-Based-Water-TDS-Quality-Monitor/tree/main"))),
        Project("TinyML Edge-AI Environmental Monitoring Prototype", "TinyML", status = "Prototype"),
        Project("ESP32 OLED Robot Face — 35 Modes (Games + Clock + Animations)", "ESP32 · Display",
            listOf(ProjectLink("Code", GH + "ESP32-OLED-Robot-Face-35-Modes-Smart-Display-Games-Clock-Animations-/tree/main"))),
        Project("IoT Arrhythmia Detection & Prediction System", "IoT · Health",
            listOf(ProjectLink("Code", GH + "IoT-based-Arrhythmia-detection-and-prediction-system"))),
        Project("BLE-Based Smart Attendance System (Secret Algorithm)", "BLE", status = "Private"),
        Project("HydroWatch: ESP32 Smart Water Monitoring (Cloud)", "ESP32 · Cloud",
            listOf(ProjectLink("Code", GH + "IoT-Based-Hydroponic-plant-Monitoring-and-Water-Quality-Analysis-"))),
        Project("RGB Picture Printing on Rounded SPI OLED Display", "Display",
            listOf(ProjectLink("Code", GH + "RGB-picture-printing-magic-on-Rounded-SPI-OLED-Display"))),
        Project("ESP32-CAM Web-Based Surveillance System", "ESP32-CAM",
            listOf(ProjectLink("Code", GH + "ESP32-Cam-Custom-web-server"))),
        Project("ESP32 LoRa Bridge Communication System", "LoRa · Research", status = "Research"),
        Project("Prossash: IoT Nebulizer & Patient Tracking System", "IoT · Health",
            listOf(ProjectLink("Code", GH + "Prossas")))
    )
}