package com.example.energymeter

import com.google.gson.annotations.SerializedName

/**
 * One row from the Supabase "readings" table.
 */
data class EnergyReading(
    @SerializedName("device_id")    val deviceId: String? = null,
    @SerializedName("voltage")      val voltage: Double? = null,
    @SerializedName("current")      val current: Double? = null,
    @SerializedName("power")        val power: Double? = null,
    @SerializedName("energy")       val energy: Double? = null,
    @SerializedName("frequency")    val frequency: Double? = null,
    @SerializedName("power_factor") val powerFactor: Double? = null,
    @SerializedName("created_at")   val createdAt: String? = null
)
