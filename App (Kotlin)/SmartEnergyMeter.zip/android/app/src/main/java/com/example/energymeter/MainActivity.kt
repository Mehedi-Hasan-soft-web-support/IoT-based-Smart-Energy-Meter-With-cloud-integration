package com.example.energymeter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val store = remember { SettingsStore(ctx) }
            var settings by remember { mutableStateOf(store.load().also { AppConfig.apply(it) }) }
            val update: (Settings) -> Unit = { ns -> settings = ns; AppConfig.apply(ns); store.save(ns) }
            AppTheme(settings.themeIndex, settings.dark) { AppRoot(settings, update) }
        }
    }
}

private val NAV = listOf(
    "" to "Monitor", "" to "Analytics", "" to "Net", "" to "Settings", "☰" to "Dev"
)

@Composable
fun AppRoot(settings: Settings, update: (Settings) -> Unit, vm: EnergyViewModel = viewModel()) {
    val c = LocalPal.current
    val state by vm.state.collectAsState()
    var tab by remember { mutableStateOf(0) }

    Scaffold(
        containerColor = c.bg,
        topBar = {
            Column(Modifier.background(c.surface).statusBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
//                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
//                            .background(Brush.linearGradient(listOf(c.primary, c.secondary))),
//                            contentAlignment = Alignment.Center) { Text("", fontSize = 17.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Smart Energy Meter", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(NAV[tab].second, color = c.muted, fontSize = 12.sp)
                        }
                    }
                    StatusPill(state.connected, state.loading)
                }
                if (!settings.navBottom) TopTabs(tab) { tab = it }
            }
        },
        bottomBar = { if (settings.navBottom) BottomNav(tab) { tab = it } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> MonitorScreen(state)
                1 -> AnalyticsScreen(state, vm)
                2 -> NetScreen(state, settings)
                3 -> SettingsScreen(settings, update, vm)
                else -> DeveloperScreen()
            }
        }
    }
}

@Composable
fun BottomNav(tab: Int, onSel: (Int) -> Unit) {
    val c = LocalPal.current
    NavigationBar(containerColor = c.surface, modifier = Modifier.navigationBarsPadding()) {
        NAV.forEachIndexed { i, (emo, label) ->
            NavigationBarItem(
                selected = tab == i, onClick = { onSel(i) },
                icon = { Text(emo, fontSize = 18.sp) },
                label = { Text(label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = c.primary, selectedTextColor = c.primary,
                    indicatorColor = c.primary.copy(alpha = 0.14f),
                    unselectedIconColor = c.muted, unselectedTextColor = c.muted
                )
            )
        }
    }
}

@Composable
fun TopTabs(tab: Int, onSel: (Int) -> Unit) {
    val c = LocalPal.current
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp, 2.dp, 12.dp, 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NAV.forEachIndexed { i, (emo, label) ->
            val active = tab == i
            Box(Modifier.clip(RoundedCornerShape(24.dp))
                .background(if (active) c.primary else c.bg)
                .clickable { onSel(i) }.padding(14.dp, 9.dp)) {
                Text("$emo $label", color = if (active) Color.White else c.muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ============================================================
//  MONITOR
// ============================================================
@Composable
fun MonitorScreen(state: UiState) {
    val c = LocalPal.current
    val r = state.latest
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        SectionTitle("Live Monitoring", if (r != null) "updated ${shortTime(r.createdAt)}" else "waiting for data")
        val tiles = listOf(
            Triple("Voltage", fmt(r?.voltage, 1), "V"), Triple("Current", fmt(r?.current, 3), "A"),
            Triple("Power", fmt(r?.power, 1), "W"), Triple("Energy", fmt(r?.energy, 3), "kWh"),
            Triple("Frequency", fmt(r?.frequency, 1), "Hz"), Triple("Power Factor", fmt(r?.powerFactor, 2), "")
        )
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (l, v, u) -> Tile(Modifier.weight(1f), l, v, u) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Panel("Live Power") { LineChartView(state.powerSeries, c.primary, 160.dp) }
        Spacer(Modifier.height(12.dp))
        Panel("Load & Power Factor") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                val load = ((r?.power ?: 0.0) / AppConfig.maxPower).toFloat().coerceIn(0f, 1f)
                GaugeView(load, c.primary, c.line) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${(load * 100).toInt()}%", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("load", color = c.muted, fontSize = 11.sp)
                    }
                }
                val pf = (r?.powerFactor ?: 0.0).toFloat().coerceIn(0f, 1f)
                GaugeView(pf, c.secondary, c.line) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(fmt(r?.powerFactor, 2), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("PF", color = c.muted, fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ============================================================
//  ANALYTICS
// ============================================================
@Composable
fun AnalyticsScreen(state: UiState, vm: EnergyViewModel) {
    val c = LocalPal.current
    val a = state.analysis
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        SectionTitle("Consumption Analytics", when (state.range) {
            Range.DAILY -> "Today · hourly"; Range.MONTHLY -> "This month · daily"; Range.YEARLY -> "This year · monthly"
        })
        Seg(listOf("Daily", "Monthly", "Yearly"), state.range.ordinal) { vm.setRange(Range.values()[it]) }
        Spacer(Modifier.height(12.dp))
        val cost = a.consumed * AppConfig.tariff.toFloat()
        val stats = listOf(
            "Consumed" to "${fmt(a.consumed.toDouble(), 3)} kWh",
            "Avg Power" to "${fmt(a.avgPower.toDouble(), 0)} W",
            "Peak" to "${fmt(a.peakPower.toDouble(), 0)} W",
            "Avg Voltage" to "${fmt(a.avgVoltage.toDouble(), 1)} V",
            "Est. Cost" to "%.2f %s".format(cost, AppConfig.currency)
        )
        stats.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (k, v) -> StatCard(Modifier.weight(1f), k, v) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(10.dp))
        Panel("Energy per period (kWh)") { BarChartView(a.energyPerBucket, c.primary, 180.dp) }
        Spacer(Modifier.height(12.dp))
        Panel("Average power (W)") { LineChartView(a.avgPowerPerBucket, c.secondary, 160.dp) }
        Spacer(Modifier.height(24.dp))
    }
}

// ============================================================
//  NET METERING
// ============================================================
@Composable
fun NetScreen(state: UiState, settings: Settings) {
    val c = LocalPal.current
    val importKwh = state.analysis.consumed
    val exportKwh = settings.exportKwh
    val net = importKwh - exportKwh
    val bill = importKwh * settings.tariff - exportKwh * settings.feedIn
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        SectionTitle("Net Metering", "grid import vs export (this ${state.range.name.lowercase()})")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(Modifier.weight(1f), "Import (grid)", "${fmt(importKwh.toDouble(), 3)} kWh")
            StatCard(Modifier.weight(1f), "Export (solar)", "${fmt(exportKwh.toDouble(), 3)} kWh")
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(Modifier.weight(1f), "Net units", "${fmt(net.toDouble(), 3)} kWh")
            StatCard(Modifier.weight(1f), "Net bill", "%.2f %s".format(bill, settings.currency))
        }
        Spacer(Modifier.height(12.dp))
        Panel("Import vs Export") {
            DualBar(importKwh, exportKwh, c.primary, c.secondary, 160.dp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Legend(c.primary, "Import"); Legend(c.secondary, "Export")
            }
        }
        Spacer(Modifier.height(10.dp))
        Panel("How it works") {
            Text("Import is the energy your meter measured from the grid. Export is your " +
                "estimated solar feed-in (set it in Settings → Net metering). " +
                "Net bill = import × tariff − export × feed-in rate.",
                color = c.muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ============================================================
//  SETTINGS
// ============================================================
@Composable
fun SettingsScreen(settings: Settings, update: (Settings) -> Unit, vm: EnergyViewModel) {
    val c = LocalPal.current
    var dialog by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        SectionTitle("Settings", "themes, navigation, metering & data")

        // ----- Appearance -----
        Panel("Theme (${THEMES.size})") {
            THEMES.chunked(4).forEachIndexed { rowIdx, row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEachIndexed { colIdx, t ->
                        val idx = rowIdx * 4 + colIdx
                        val sel = settings.themeIndex == idx
                        Column(Modifier.weight(1f).clickable { update(settings.copy(themeIndex = idx)) },
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(Color(t.primary), Color(t.secondary))))
                                .padding(3.dp)) {
                                if (sel) Text("✓", color = Color.White, fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
                            }
                            Text(t.name, color = if (sel) c.primary else c.muted, fontSize = 10.sp,
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Panel("Display mode") {
            Seg(listOf("System", "Light", "Dark"), settings.dark) { update(settings.copy(dark = it)) }
        }
        Spacer(Modifier.height(12.dp))
        Panel("Navigation bar position") {
            Seg(listOf("Bottom", "Top"), if (settings.navBottom) 0 else 1) { update(settings.copy(navBottom = it == 0)) }
            Spacer(Modifier.height(6.dp))
            Text("Move the nav bar to suit your phone (gesture bars, one-hand use, notches).",
                color = c.muted, fontSize = 12.sp)
        }

        // ----- Metering -----
        Spacer(Modifier.height(12.dp))
        Panel("Metering") {
            TextFieldRow("Device ID", settings.deviceId, false) { update(settings.copy(deviceId = it)); vm.reload() }
            NumRow("Tariff (per kWh)", settings.tariff) { update(settings.copy(tariff = it)) }
            TextFieldRow("Currency", settings.currency, false) { update(settings.copy(currency = it)) }
            NumRow("Max power for gauge (W)", settings.maxPower) { update(settings.copy(maxPower = it)) }
            NumRowInt("Refresh interval (sec)", settings.refreshSec) { update(settings.copy(refreshSec = it)) }
        }

        // ----- Net metering -----
        Spacer(Modifier.height(12.dp))
        Panel("Net metering") {
            NumRow("Feed-in tariff (per kWh)", settings.feedIn) { update(settings.copy(feedIn = it)) }
            NumRow("Estimated export (kWh)", settings.exportKwh) { update(settings.copy(exportKwh = it)) }
        }

        // ----- Data manager -----
        Spacer(Modifier.height(12.dp))
        Panel("Data manager") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    dialog = "Delete readings older than 30 days?" to { vm.deleteOld { ok -> toast = if (ok) "Old data cleared" else "Delete failed" } }
                }, modifier = Modifier.weight(1f)) { Text("Clear > 30d") }
                Button(onClick = {
                    dialog = "Delete ALL data for this device?" to { vm.deleteAll { ok -> toast = if (ok) "All data deleted" else "Delete failed" } }
                }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5484D))) {
                    Text("Delete all", color = Color.White)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("SmartEnergy · connected to Supabase · device ${settings.deviceId}",
            color = c.muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(24.dp))
    }

    toast?.let {
        LaunchedEffect(it) { kotlinx.coroutines.delay(2200); toast = null }
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomCenter) { Snackbar { Text(it) } }
    }
    dialog?.let { (msg, action) ->
        AlertDialog(onDismissRequest = { dialog = null },
            title = { Text("Confirm delete") }, text = { Text("$msg This cannot be undone.") },
            confirmButton = { TextButton(onClick = { action(); dialog = null }) { Text("Delete", color = Color(0xFFE5484D)) } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } })
    }
}

// ============================================================
//  DEVELOPER
// ============================================================
@Composable
fun DeveloperScreen() {
    val c = LocalPal.current
    val uri = LocalUriHandler.current
    LazyColumn(Modifier.fillMaxSize().padding(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.card).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(66.dp).clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(c.primary, c.secondary))),
                        contentAlignment = Alignment.Center) {
                        Text(Dev.INITIALS, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(Dev.NAME, color = c.text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text(Dev.ROLE, color = c.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(Dev.BIO, color = c.muted, fontSize = 13.sp, lineHeight = 19.sp)
                Spacer(Modifier.height(10.dp))
                Chip("GitHub ↗") { uri.openUri(Dev.GITHUB) }
            }
            Spacer(Modifier.height(14.dp))
            Text("Projects (${Dev.PROJECTS.size})", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
        }
        items(Dev.PROJECTS) { p ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(c.card).padding(16.dp)) {
                Text(p.name, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 18.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(c.primary.copy(alpha = 0.12f)).padding(9.dp, 5.dp)) {
                        Text(p.tag, color = c.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.width(8.dp))
                    p.links.forEach { link -> Chip("${link.label} ↗") { uri.openUri(link.url) }; Spacer(Modifier.width(6.dp)) }
                    p.status?.let {
                        Box(Modifier.clip(RoundedCornerShape(20.dp)).background(c.bg).padding(9.dp, 5.dp)) {
                            Text(it, color = c.muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ============================================================
//  SHARED PIECES
// ============================================================
@Composable
fun SectionTitle(t: String, s: String) {
    val c = LocalPal.current
    Column(Modifier.padding(bottom = 12.dp)) {
        Text(t, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(s, color = c.muted, fontSize = 12.sp)
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalPal.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.card).padding(16.dp)) {
        Text(title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp)); content()
    }
}

@Composable
fun Tile(modifier: Modifier, label: String, value: String, unit: String) {
    val c = LocalPal.current
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(c.card).padding(16.dp)) {
        Text(label, color = c.muted, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (unit.isNotEmpty()) { Spacer(Modifier.width(3.dp)); Text(unit, color = c.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 3.dp)) }
        }
    }
}

@Composable
fun StatCard(modifier: Modifier, k: String, v: String) {
    val c = LocalPal.current
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(c.card).padding(14.dp)) {
        Text(k, color = c.muted, fontSize = 11.sp); Spacer(Modifier.height(4.dp))
        Text(v, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Seg(options: List<String>, selected: Int, onSel: (Int) -> Unit) {
    val c = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(c.bg).padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEachIndexed { i, o ->
            val active = selected == i
            Box(Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                .background(if (active) c.primary else Color.Transparent)
                .clickable { onSel(i) }.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                Text(o, color = if (active) Color.White else c.muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun Legend(color: Color, label: String) {
    val c = LocalPal.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(11.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Spacer(Modifier.width(6.dp)); Text(label, color = c.muted, fontSize = 12.sp)
    }
}

@Composable
fun Chip(text: String, onClick: () -> Unit) {
    val c = LocalPal.current
    Box(Modifier.clip(RoundedCornerShape(30.dp)).background(c.bg).clickable { onClick() }.padding(11.dp, 6.dp)) {
        Text(text, color = c.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TextFieldRow(label: String, initial: String, numeric: Boolean, onValue: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    OutlinedTextField(value = v, onValueChange = { v = it; onValue(it) }, label = { Text(label) }, singleLine = true,
        keyboardOptions = if (numeric) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
}

@Composable
fun NumRow(label: String, initial: Float, onValue: (Float) -> Unit) {
    var v by remember { mutableStateOf(if (initial == initial.toLong().toFloat()) initial.toLong().toString() else initial.toString()) }
    OutlinedTextField(value = v, onValueChange = { v = it; it.toFloatOrNull()?.let(onValue) }, label = { Text(label) },
        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
}

@Composable
fun NumRowInt(label: String, initial: Int, onValue: (Int) -> Unit) {
    var v by remember { mutableStateOf(initial.toString()) }
    OutlinedTextField(value = v, onValueChange = { v = it; it.toIntOrNull()?.let(onValue) }, label = { Text(label) },
        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
}

@Composable
fun StatusPill(connected: Boolean, loading: Boolean) {
    val c = LocalPal.current
    val (dot, label) = when { loading -> c.muted to "…"; connected -> Color(0xFF2BB34A) to "Online"; else -> Color(0xFFE5484D) to "Offline" }
    Row(Modifier.clip(RoundedCornerShape(30.dp)).background(c.bg).padding(10.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(dot))
        Spacer(Modifier.width(6.dp)); Text(label, color = c.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---- helpers ----
fun fmt(v: Double?, digits: Int): String =
    if (v == null || v.isNaN()) "--" else String.format(Locale.US, "%.${digits}f", v)

fun shortTime(iso: String?): String {
    if (iso == null) return "--"
    return try {
        val inF = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val d = inF.parse(iso.substringBefore(".").substringBefore("+"))
        SimpleDateFormat("HH:mm:ss", Locale.US).format(d!!)
    } catch (e: Exception) { iso.substringAfter("T").take(8) }
}
