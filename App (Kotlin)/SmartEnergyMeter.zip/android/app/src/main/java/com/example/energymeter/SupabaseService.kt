package com.example.energymeter

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

object Supa {
    const val URL = "https://oacpdzphwojhnyuhoeqe.supabase.co/rest/v1/"
    const val KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9hY3BkenBod29qaG55dWhvZXFlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM4MzkzMzAsImV4cCI6MjA5OTQxNTMzMH0.CtgC01UX3aIqx7p0QZCWC_ymmT2OeZsj6K4Y3Q8dkFM"
}

interface SupabaseApi {
    @GET("readings")
    suspend fun getLatest(
        @Query("device_id") dev: String,
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 40
    ): List<EnergyReading>

    @GET("readings")
    suspend fun getSince(
        @Query("created_at") since: String,
        @Query("device_id") dev: String,
        @Query("order") order: String = "created_at.asc",
        @Query("limit") limit: Int = 5000
    ): List<EnergyReading>

    @DELETE("readings")
    @Headers("Prefer: return=minimal")
    suspend fun delete(
        @Query("device_id") dev: String,
        @Query("created_at") cutoff: String? = null
    ): Response<Unit>
}

object SupabaseService {
    private val auth = Interceptor { chain ->
        chain.proceed(
            chain.request().newBuilder()
                .addHeader("apikey", Supa.KEY)
                .addHeader("Authorization", "Bearer ${Supa.KEY}")
                .build()
        )
    }
    private val client = OkHttpClient.Builder().addInterceptor(auth).build()
    val api: SupabaseApi = Retrofit.Builder()
        .baseUrl(Supa.URL).client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(SupabaseApi::class.java)
}
