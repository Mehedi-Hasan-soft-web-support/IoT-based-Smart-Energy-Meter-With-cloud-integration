package com.example.energymeter

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class Range { DAILY, MONTHLY, YEARLY }

data class Analysis(
    val labels: List<String> = emptyList(),
    val energyPerBucket: List<Float> = emptyList(),
    val avgPowerPerBucket: List<Float> = emptyList(),
    val consumed: Float = 0f,
    val avgPower: Float = 0f,
    val peakPower: Float = 0f,
    val avgVoltage: Float = 0f
)

data class UiState(
    val latest: EnergyReading? = null,
    val history: List<EnergyReading> = emptyList(),
    val powerSeries: List<Float> = emptyList(),
    val connected: Boolean = false,
    val loading: Boolean = true,
    val error: String? = null,
    val range: Range = Range.DAILY,
    val analysis: Analysis = Analysis()
)

class EnergyViewModel : ViewModel() {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    init { startPolling(); loadAnalysis(Range.DAILY) }

    private fun dev() = "eq.${AppConfig.deviceId}"

    private fun startPolling() {
        viewModelScope.launch {
            while (true) {
                fetchLatest()
                delay(AppConfig.refreshMs)
            }
        }
    }

    private suspend fun fetchLatest() {
        try {
            val rows = SupabaseService.api.getLatest(dev())
            _state.value = _state.value.copy(
                latest = rows.firstOrNull(),
                history = rows,
                powerSeries = rows.reversed().map { (it.power ?: 0.0).toFloat() },
                connected = rows.isNotEmpty(), loading = false, error = null
            )
        } catch (e: Exception) {
            _state.value = _state.value.copy(connected = false, loading = false, error = e.message)
        }
    }

    fun reload() { viewModelScope.launch { fetchLatest() }; loadAnalysis(_state.value.range) }

    fun setRange(r: Range) { _state.value = _state.value.copy(range = r); loadAnalysis(r) }

    private fun startCal(r: Range): Calendar {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        when (r) {
            Range.DAILY -> {}
            Range.MONTHLY -> c.set(Calendar.DAY_OF_MONTH, 1)
            Range.YEARLY -> { c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.MONTH, 0) }
        }
        return c
    }

    private fun parse(s: String?): Date? {
        if (s == null) return null
        return try { iso.parse(s.substringBefore(".").substringBefore("+").trim()) } catch (e: Exception) { null }
    }

    fun loadAnalysis(r: Range) {
        viewModelScope.launch {
            try {
                val sinceIso = "gte." + iso.format(startCal(r).time) + "Z"
                val rows = SupabaseService.api.getSince(since = sinceIso, dev = dev())
                _state.value = _state.value.copy(analysis = aggregate(rows, r))
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = e.message)
            }
        }
    }

    private fun aggregate(rows: List<EnergyReading>, r: Range): Analysis {
        val months = arrayOf("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
        val now = Calendar.getInstance()
        val buckets: Int; val labels: List<String>
        when (r) {
            Range.DAILY -> { buckets = 24; labels = (0 until 24).map { "$it" } }
            Range.MONTHLY -> { buckets = now.getActualMaximum(Calendar.DAY_OF_MONTH); labels = (1..buckets).map { "$it" } }
            Range.YEARLY -> { buckets = 12; labels = months.toList() }
        }
        val eMin = arrayOfNulls<Double>(buckets); val eMax = arrayOfNulls<Double>(buckets)
        val pSum = DoubleArray(buckets); val pCnt = IntArray(buckets)
        val vSum = DoubleArray(buckets); val vCnt = IntArray(buckets)
        val cal = Calendar.getInstance()
        rows.forEach { x ->
            val d = parse(x.createdAt) ?: return@forEach
            cal.time = d
            val i = when (r) {
                Range.DAILY -> cal.get(Calendar.HOUR_OF_DAY)
                Range.MONTHLY -> cal.get(Calendar.DAY_OF_MONTH) - 1
                Range.YEARLY -> cal.get(Calendar.MONTH)
            }
            if (i in 0 until buckets) {
                x.energy?.let { e -> if (eMin[i] == null || e < eMin[i]!!) eMin[i] = e; if (eMax[i] == null || e > eMax[i]!!) eMax[i] = e }
                x.power?.let { pSum[i] += it; pCnt[i]++ }
                x.voltage?.let { vSum[i] += it; vCnt[i]++ }
            }
        }
        val energyBk = (0 until buckets).map { i -> val mn = eMin[i]; if (mn == null) 0f else (eMax[i]!! - mn).coerceAtLeast(0.0).toFloat() }
        val avgPowBk = (0 until buckets).map { i -> if (pCnt[i] > 0) (pSum[i] / pCnt[i]).toFloat() else 0f }
        val allP = rows.mapNotNull { it.power }; val allV = rows.mapNotNull { it.voltage }
        val consumed = if (rows.isNotEmpty()) ((rows.last().energy ?: 0.0) - (rows.first().energy ?: 0.0)).coerceAtLeast(0.0) else 0.0
        return Analysis(labels, energyBk, avgPowBk, consumed.toFloat(),
            if (allP.isNotEmpty()) allP.average().toFloat() else 0f,
            (allP.maxOrNull() ?: 0.0).toFloat(),
            if (allV.isNotEmpty()) allV.average().toFloat() else 0f)
    }

    fun deleteAll(onDone: (Boolean) -> Unit) = runDelete(null, onDone)
    fun deleteOld(onDone: (Boolean) -> Unit) {
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -30)
        runDelete("lt." + iso.format(c.time) + "Z", onDone)
    }
    private fun runDelete(cutoff: String?, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            try { val res = SupabaseService.api.delete(dev(), cutoff); onDone(res.isSuccessful); fetchLatest(); loadAnalysis(_state.value.range) }
            catch (e: Exception) { _state.value = _state.value.copy(error = e.message); onDone(false) }
        }
    }
}
