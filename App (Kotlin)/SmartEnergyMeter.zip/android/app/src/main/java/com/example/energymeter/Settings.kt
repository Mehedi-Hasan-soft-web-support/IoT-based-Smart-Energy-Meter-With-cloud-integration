package com.example.energymeter

import android.content.Context

/** Runtime config read by the network layer and the UI. */
object AppConfig {
    @Volatile var deviceId: String = "meter_01"
    @Volatile var refreshMs: Long = 5000L
    var tariff: Double = 8.0
    var currency: String = "BDT"
    var maxPower: Double = 2000.0
    var feedIn: Double = 5.0          // feed-in tariff for exported energy
    val co2PerKwh: Double = 0.70

    fun apply(s: Settings) {
        deviceId = s.deviceId
        refreshMs = (s.refreshSec.coerceAtLeast(2)) * 1000L
        tariff = s.tariff.toDouble()
        currency = s.currency
        maxPower = s.maxPower.toDouble().coerceAtLeast(1.0)
        feedIn = s.feedIn.toDouble()
    }
}

/** All user preferences. */
data class Settings(
    val themeIndex: Int = 0,
    val navBottom: Boolean = true,     // true = bottom bar, false = top tabs
    val dark: Int = 0,                 // 0 system, 1 light, 2 dark
    val tariff: Float = 8f,
    val currency: String = "BDT",
    val maxPower: Float = 2000f,
    val deviceId: String = "meter_01",
    val refreshSec: Int = 5,
    val feedIn: Float = 5f,
    val exportKwh: Float = 0f          // estimated exported energy per period (net metering)
)

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("sem_settings", Context.MODE_PRIVATE)

    fun load() = Settings(
        themeIndex = p.getInt("theme", 0),
        navBottom = p.getBoolean("navBottom", true),
        dark = p.getInt("dark", 0),
        tariff = p.getFloat("tariff", 8f),
        currency = p.getString("currency", "BDT") ?: "BDT",
        maxPower = p.getFloat("maxPower", 2000f),
        deviceId = p.getString("device", "meter_01") ?: "meter_01",
        refreshSec = p.getInt("refresh", 5),
        feedIn = p.getFloat("feedIn", 5f),
        exportKwh = p.getFloat("exportKwh", 0f)
    )

    fun save(s: Settings) {
        p.edit()
            .putInt("theme", s.themeIndex)
            .putBoolean("navBottom", s.navBottom)
            .putInt("dark", s.dark)
            .putFloat("tariff", s.tariff)
            .putString("currency", s.currency)
            .putFloat("maxPower", s.maxPower)
            .putString("device", s.deviceId)
            .putInt("refresh", s.refreshSec)
            .putFloat("feedIn", s.feedIn)
            .putFloat("exportKwh", s.exportKwh)
            .apply()
    }
}
