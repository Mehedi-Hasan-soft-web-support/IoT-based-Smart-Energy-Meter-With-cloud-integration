package com.example.energymeter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LineChartView(values: List<Float>, color: Color, height: Dp) {
    Canvas(Modifier.fillMaxWidth().height(height)) {
        if (values.size < 2) return@Canvas
        val mx = (values.maxOrNull() ?: 1f).coerceAtLeast(0.001f)
        val sx = size.width / (values.size - 1)
        val pts = values.mapIndexed { i, v -> Offset(i * sx, size.height - (v / mx) * size.height * 0.9f - size.height * 0.05f) }
        val fill = Path().apply { moveTo(0f, size.height); pts.forEach { lineTo(it.x, it.y) }; lineTo(size.width, size.height); close() }
        drawPath(fill, color.copy(alpha = 0.15f))
        val line = Path().apply { moveTo(pts.first().x, pts.first().y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
        drawPath(line, color, style = Stroke(width = 4f, cap = StrokeCap.Round))
    }
}

@Composable
fun BarChartView(values: List<Float>, color: Color, height: Dp) {
    Canvas(Modifier.fillMaxWidth().height(height)) {
        if (values.isEmpty()) return@Canvas
        val mx = (values.maxOrNull() ?: 0f).coerceAtLeast(0.001f)
        val bw = size.width / values.size
        values.forEachIndexed { i, v ->
            val h = (v / mx) * size.height * 0.92f
            drawRoundRect(color, topLeft = Offset(i * bw + bw * 0.15f, size.height - h),
                size = Size(bw * 0.7f, h), cornerRadius = CornerRadius(5f, 5f))
        }
    }
}

@Composable
fun GaugeView(pct: Float, color: Color, track: Color, content: @Composable () -> Unit) {
    Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = 22f; val ins = s / 2; val arc = Size(size.width - s, size.height - s)
            drawArc(track, -90f, 360f, false, topLeft = Offset(ins, ins), size = arc, style = Stroke(s, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * pct.coerceIn(0f, 1f), false, topLeft = Offset(ins, ins), size = arc, style = Stroke(s, cap = StrokeCap.Round))
        }
        content()
    }
}

@Composable
fun DualBar(leftVal: Float, rightVal: Float, leftColor: Color, rightColor: Color, height: Dp) {
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val mx = maxOf(leftVal, rightVal, 0.001f)
        val gap = size.width * 0.18f
        val bw = (size.width - gap) / 2f
        val hL = (leftVal / mx) * size.height * 0.9f
        val hR = (rightVal / mx) * size.height * 0.9f
        drawRoundRect(leftColor, topLeft = Offset(bw * 0.15f, size.height - hL),
            size = Size(bw * 0.7f, hL), cornerRadius = CornerRadius(6f, 6f))
        drawRoundRect(rightColor, topLeft = Offset(bw + gap + bw * 0.15f, size.height - hR),
            size = Size(bw * 0.7f, hR), cornerRadius = CornerRadius(6f, 6f))
    }
}
